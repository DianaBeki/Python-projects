from audioop import add


x = 6
y = 5
print(x + y)